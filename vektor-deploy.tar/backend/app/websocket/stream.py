from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict

from fastapi import WebSocket

from app.config import get_settings
from app.data.market_data import FEED


WATCHLIST = ["AAPL", "MSFT", "NVDA", "SPY", "TSLA", "AMZN", "GOOGL", "META"]
logger = logging.getLogger("alfred.websocket.stream")


class StreamManager:
    def __init__(self):
        self.active: set[WebSocket] = set()
        self._tick_cache: Dict[str, dict] = {}

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.add(ws)
        if self._tick_cache:
            try:
                await ws.send_json({"type": "tick_batch", "data": list(self._tick_cache.values())})
            except Exception:
                pass

    def disconnect(self, ws: WebSocket):
        self.active.discard(ws)

    async def broadcast(self, message: dict):
        if not self.active:
            return
        dead = []
        for ws in list(self.active):
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for d in dead:
            self.disconnect(d)

    def update_tick(self, symbol: str, price: float, prev_close: float | None = None):
        existing = self._tick_cache.get(symbol, {})
        ref = prev_close or existing.get("prev_close") or price
        change = price - ref
        change_pct = (change / ref * 100) if ref else 0.0
        self._tick_cache[symbol] = {
            "symbol": symbol,
            "price": price,
            "prev_close": ref,
            "change": round(change, 4),
            "change_pct": round(change_pct, 4),
            "ts": _utc_iso(),
        }


manager = StreamManager()

# Previous-close cache populated at startup
_prev_close: Dict[str, float] = {}


def _utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _alpaca_tick_callback(symbol: str, price: float):
    manager.update_tick(symbol, price, _prev_close.get(symbol))


def _fetch_prev_closes() -> None:
    """Pull yesterday's close for each watchlist symbol at startup."""
    for sym in WATCHLIST:
        try:
            hist = FEED.history(sym, bars=5)
            if hist is not None and len(hist) >= 2:
                _prev_close[sym] = float(hist["close"].iloc[-2])
        except Exception:
            pass
    logger.info("Previous closes loaded for %s symbols", len(_prev_close))


def _collect_tick_and_positions(symbols: list[str]) -> tuple[list[dict], list]:
    """
    Blocking market data + positions collection, intended to run off-thread.
    """
    tick_data: list[dict] = []
    for sym in symbols:
        px = FEED.price(sym)
        if px and px > 0:
            manager.update_tick(sym, px, _prev_close.get(sym))
            tick_data.append(manager._tick_cache[sym])

    from app.core.context import broker

    positions = broker.list_positions(lambda s: FEED.price(s))
    return tick_data, positions


async def stream_loop():
    settings = get_settings()

    # Fetch prev closes first so change is meaningful from the first tick.
    _fetch_prev_closes()

    FEED.subscribe(_alpaca_tick_callback)
    if settings.ALPACA_STREAM_ENABLED:
        FEED.start_stream(WATCHLIST)
    else:
        logger.info("Alpaca stream disabled; using REST/cached prices only.")

    logger.info("Stream loop started; broadcast_interval=%ss", settings.WEBSOCKET_BROADCAST_INTERVAL)

    while True:
        await asyncio.sleep(settings.WEBSOCKET_BROADCAST_INTERVAL)

        if not manager.active:
            continue

        try:
            timeout_seconds = max(0.2, float(settings.WEBSOCKET_STREAM_FETCH_TIMEOUT_SECONDS))
            tick_data, positions = await asyncio.wait_for(
                asyncio.to_thread(_collect_tick_and_positions, WATCHLIST),
                timeout=timeout_seconds,
            )

            if tick_data:
                await manager.broadcast(
                    {
                        "type": "tick_batch",
                        "data": tick_data,
                        "ts": _utc_iso(),
                    }
                )
            if positions:
                await manager.broadcast(
                    {
                        "type": "positions_update",
                        "data": positions,
                        "ts": _utc_iso(),
                    }
                )

        except asyncio.TimeoutError:
            logger.warning("Stream loop fetch timeout; skipping cycle")
        except Exception as exc:
            logger.warning("Stream loop error: %s", exc)
